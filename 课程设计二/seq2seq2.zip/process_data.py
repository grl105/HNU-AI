import argparse
import ast
import collections
import logging
import numpy as np
import os

from mindspore import context
from mindspore.mindrecord import FileWriter
from tokenization import WhiteSpaceTokenizer


class SampleInstance():
    def __init__(self, source_tokens, target_tokens):
        self.source_tokens = source_tokens
        self.target_tokens = target_tokens


def get_instance_features(instance, tokenizer_src, tokenizer_trg, max_seq_length, bucket):
    def _find_bucket_length(source_tokens, target_tokens):
        source_ids = tokenizer_src.convert_tokens_to_ids(source_tokens)
        target_ids = tokenizer_trg.convert_tokens_to_ids(target_tokens)
        num = max(len(source_ids), len(target_ids))
        if num > bucket[-1]:
            return None
        for index in range(1, len(bucket)):
            if bucket[index - 1] < num <= bucket[index]:
                return bucket[index]
        return bucket[0]

    def _convert_ids_and_mask(tokenizer, input_tokens, seq_max_bucket_length):
        input_ids = tokenizer.convert_tokens_to_ids(input_tokens)
        input_mask = [1] * len(input_ids)

        while len(input_ids) < seq_max_bucket_length:
            input_ids.append(1)  # Use <pad> token id
            input_mask.append(0)

        return input_ids[:seq_max_bucket_length], input_mask[:seq_max_bucket_length]

    seq_max_bucket_length = _find_bucket_length(instance.source_tokens, instance.target_tokens)
    if seq_max_bucket_length is None:
        return None, None

    source_ids, source_mask = _convert_ids_and_mask(tokenizer_src, instance.source_tokens, seq_max_bucket_length)
    target_ids, target_mask = _convert_ids_and_mask(tokenizer_trg, instance.target_tokens, seq_max_bucket_length)

    features = collections.OrderedDict()
    features["source_ids"] = np.asarray(source_ids)
    features["source_mask"] = np.asarray(source_mask)
    features["target_ids"] = np.asarray(target_ids)
    features["target_mask"] = np.asarray(target_mask)

    return features, seq_max_bucket_length


def create_training_instance(source_words, target_words, max_seq_length, clip_to_max_len):
    # Increase buffer for special tokens
    effective_max_length = max_seq_length - 2  # Reserve space for <sos> and <eos>

    if len(source_words) > effective_max_length or len(target_words) > effective_max_length:
        if clip_to_max_len:
            source_words = source_words[:effective_max_length]
            target_words = target_words[:effective_max_length]
        else:
            return None

    source_tokens = ["<sos>"] + source_words + ["<eos>"]
    target_tokens = ["<sos>"] + target_words + ["<eos>"]

    return SampleInstance(source_tokens=source_tokens, target_tokens=target_tokens)


def main():
    parser = argparse.ArgumentParser(description="Translation Data Processing")
    parser.add_argument("--num_splits", type=int, default=1,
                        help='The MindRecord file will be split into the number of partition.')
    parser.add_argument("--clip_to_max_len", type=ast.literal_eval, default=True,
                        help='clip sequences to maximum sequence length.')
    parser.add_argument("--max_seq_length", type=int, default=256,
                        help='Maximum sequence length.')
    parser.add_argument("--bucket", type=ast.literal_eval, default=[64, 128, 192, 256],
                        help='bucket sequence length')
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )

    os.makedirs("nltk_mindrecord", exist_ok=True)

    tokenizer_src = WhiteSpaceTokenizer("nltk_predata/vocab.zh")
    tokenizer_trg = WhiteSpaceTokenizer("nltk_predata/vocab.en")

    input_files = ["nltk_predata/train.zh.tok", "nltk_predata/train.en.tok"]
    output_file = "nltk_mindrecord/mindrecord"

    # 统计信息变量
    total_sentences = 0
    clipped_sentences = 0
    bucket_distribution = collections.defaultdict(int)

    logging.info("Starting data processing...")
    total_written = 0
    total_read = 0
    feature_dict = {i: [] for i in args.bucket}

    with open(input_files[0], "r", encoding="utf-8") as reader_source, \
            open(input_files[1], "r", encoding="utf-8") as reader_target:

        while True:
            source_line = reader_source.readline()
            target_line = reader_target.readline()

            if not source_line or not target_line:
                break

            total_read += 1
            if total_read % 10000 == 0:
                logging.info(f"Processed {total_read} lines...")
                logging.info(f"Current bucket distribution: {dict(bucket_distribution)}")

            total_sentences += 1

            source_tokens = tokenizer_src.tokenize(source_line.strip())
            target_tokens = tokenizer_trg.tokenize(target_line.strip())

            # 记录原始长度
            orig_source_len = len(source_tokens)
            orig_target_len = len(target_tokens)

            instance = create_training_instance(
                source_tokens, target_tokens,
                args.max_seq_length,
                args.clip_to_max_len
            )

            if instance is None:
                continue

            # 检查是否被截断
            if len(instance.source_tokens) < orig_source_len + 2 or \
                    len(instance.target_tokens) < orig_target_len + 2:
                clipped_sentences += 1

            features, seq_max_bucket_length = get_instance_features(
                instance, tokenizer_src, tokenizer_trg,
                args.max_seq_length, args.bucket
            )

            if features is not None and seq_max_bucket_length is not None:
                feature_dict[seq_max_bucket_length].append(features)
                bucket_distribution[seq_max_bucket_length] += 1

    # 打印统计信息
    logging.info(f"\nData Processing Statistics:")
    logging.info(f"Total sentences processed: {total_sentences}")
    logging.info(f"Sentences clipped: {clipped_sentences} ({clipped_sentences / total_sentences * 100:.2f}%)")
    logging.info(f"Final bucket distribution: {dict(bucket_distribution)}")

    # Write MindRecord files
    for i in args.bucket:
        features_ = feature_dict[i]
        if not features_:
            logging.info(f"No samples for bucket length {i}, skipping...")
            continue

        if args.num_splits == 1:
            output_file_name = f"{output_file}_{i}"
        else:
            output_file_name = f"{output_file}_{i}_"

        writer = FileWriter(output_file_name, args.num_splits)

        data_schema = {
            "source_ids": {"type": "int64", "shape": [-1]},
            "source_mask": {"type": "int64", "shape": [-1]},
            "target_ids": {"type": "int64", "shape": [-1]},
            "target_mask": {"type": "int64", "shape": [-1]}
        }

        writer.add_schema(data_schema, "translation")
        logging.info(f"Bucket length {i} has {len(features_)} samples, writing...")

        for item in features_:
            writer.write_raw_data([item])
            total_written += 1

        writer.commit()

    logging.info(f"Processing completed. Total written: {total_written} instances")


if __name__ == "__main__":
    main()