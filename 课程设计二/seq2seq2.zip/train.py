import os
import time
from mindspore import context

from mindspore.train import Model
from mindspore.nn.optim import Adam
from mindspore.communication.management import init
from mindspore.train.loss_scale_manager import DynamicLossScaleManager
from mindspore.train.callback import Callback, CheckpointConfig, ModelCheckpoint, TimeMonitor

from src.seq2seq import Seq2Seq
from src.lr_schedule import dynamic_lr
from src.dataset import create_gru_dataset
from src.gru_for_train import GRUWithLossCell, GRUTrainOneStepWithLossScaleCell
import os


# 添加设备配置
context.set_context(mode=context.GRAPH_MODE,
                   device_target="Ascend",
                   device_id=0,
                   max_device_memory="24GB",
                   memory_optimize_level="O1")


rank = 0
device_num = 1

mindrecord_files = [
    "nltk_mindrecord/mindrecord_64",
    "nltk_mindrecord/mindrecord_128",
    "nltk_mindrecord/mindrecord_192",
    "nltk_mindrecord/mindrecord_256"
]
outputs_dir = ""

datasets = []
for file in mindrecord_files:
    if os.path.exists(file):
        ds = create_gru_dataset(epoch_count=9,
                              batch_size=8,
                              dataset_path=file,
                              rank_size=device_num,
                              rank_id=rank,
                              num_parallel_workers=2)
        datasets.append(ds)

# 合并数据集
if len(datasets) > 1:
    dataset = datasets[0].concat(datasets[1:])
else:
    dataset = datasets[0]

dataset_size = dataset.get_dataset_size()
print("Total dataset size after merge:", dataset_size)

network = Seq2Seq()
network = GRUWithLossCell(network)

lr = dynamic_lr(dataset_size)
opt = Adam(network.trainable_params(), learning_rate=lr)

scale_manager = DynamicLossScaleManager(init_loss_scale=2**8,
                                        scale_factor=2,
                                        scale_window=2000)

update_cell = scale_manager.get_update_cell()
netwithgrads = GRUTrainOneStepWithLossScaleCell(network, opt, update_cell)


class LossCallBack(Callback):
    def __init__(self, per_print_times=1, rank_id=0):
        super(LossCallBack, self).__init__()
        if not isinstance(per_print_times, int) or per_print_times < 0:
            raise ValueError("print_step must be int and >= 0.")
        self._per_print_times = per_print_times
        self.rank_id = rank_id
        global time_stamp_init, time_stamp_first
        if not time_stamp_init:
            time_stamp_first = get_ms_timestamp()
            time_stamp_init = True

    def step_end(self, run_context):
        """Monitor the loss in training."""
        global time_stamp_first
        time_stamp_current = get_ms_timestamp()
        cb_params = run_context.original_args()
        print("time: {}, epoch: {}, step: {}, loss: {}".format(time_stamp_current - time_stamp_first,
                                                               cb_params.cur_epoch_num,
                                                               cb_params.cur_step_num,
                                                               str(cb_params.net_outputs[0].asnumpy())))
        with open("./loss_{}.log".format(self.rank_id), "a+") as f:
            f.write("time: {}, epoch: {}, step: {}, loss: {}, overflow: {}, loss_scale: {}".format(
                time_stamp_current - time_stamp_first,
                cb_params.cur_epoch_num,
                cb_params.cur_step_num,
                str(cb_params.net_outputs[0].asnumpy()),
                str(cb_params.net_outputs[1].asnumpy()),
                str(cb_params.net_outputs[2].asnumpy())))
            f.write('\n')


def get_ms_timestamp():
    t = time.time()
    return int(round(t * 1000))


time_stamp_init = False
time_stamp_first = 0
time_cb = TimeMonitor(data_size=dataset_size)
loss_cb = LossCallBack(rank_id=rank)
cb = [time_cb, loss_cb]

ckpt_config = CheckpointConfig(save_checkpoint_steps=100 * dataset_size,  # 增大保存间隔
                             keep_checkpoint_max=2)  # 减少保存的检查点数量

save_ckpt_path = os.path.join("./output_data", 'ckpt_' + str(0) + '/')
if not os.path.exists(save_ckpt_path):
    os.makedirs(save_ckpt_path)

ckpt_cb = ModelCheckpoint(config=ckpt_config,
                          directory=save_ckpt_path,
                          prefix='{}'.format(0))
cb += [ckpt_cb]

netwithgrads.set_train(True)
model = Model(netwithgrads)
print("Starting training...")
model.train(9, dataset, callbacks=cb, dataset_sink_mode=True)
