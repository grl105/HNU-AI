import numpy as np
import mindspore.common.dtype as mstype
import mindspore.dataset as ds
import mindspore.dataset.transforms.c_transforms as deC


def random_teacher_force(source_ids, target_ids, target_mask):
    """Generate random teacher force flag"""
    teacher_force = np.random.random() < 0.5
    teacher_force_array = np.array([teacher_force], dtype=bool)
    return source_ids, target_ids, teacher_force_array



def create_gru_dataset(epoch_count=1, batch_size=8, rank_size=1, rank_id=0, do_shuffle=True, dataset_path=None,
                       is_training=True, num_parallel_workers=2):
    dataset = ds.MindDataset(dataset_path,
                             columns_list=["source_ids", "target_ids", "target_mask"],
                             shuffle=do_shuffle,
                             num_parallel_workers=num_parallel_workers,
                             num_shards=rank_size,
                             shard_id=rank_id)

    # map 操作也需要指定并行工作线程数
    dataset = dataset.map(operations=random_teacher_force,
                          input_columns=["source_ids", "target_ids", "target_mask"],
                          output_columns=["source_ids", "target_ids", "teacher_force"],
                          num_parallel_workers=num_parallel_workers)  # 添加这个参数

    dataset = dataset.project(["source_ids", "target_ids", "teacher_force"])

    # 类型转换操作也添加并行工作线程数
    type_cast_op = deC.TypeCast(mstype.int32)
    type_cast_op_bool = deC.TypeCast(mstype.bool_)
    dataset = dataset.map(operations=type_cast_op,
                          input_columns="source_ids",
                          num_parallel_workers=num_parallel_workers)  # 添加这个参数

    dataset = dataset.map(operations=type_cast_op,
                          input_columns="target_ids",
                          num_parallel_workers=num_parallel_workers)  # 添加这个参数

    dataset = dataset.map(operations=type_cast_op_bool,
                          input_columns="teacher_force",
                          num_parallel_workers=num_parallel_workers)  # 添加这个参数

    dataset = dataset.batch(batch_size, drop_remainder=True)
    dataset = dataset.repeat(epoch_count)

    return dataset