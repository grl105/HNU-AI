from mindspore import Tensor, Parameter, ParameterTuple, context
import mindspore.nn as nn
import mindspore.ops.operations as P
from mindspore.ops import composite as C
from mindspore.ops import functional as F
import mindspore.common.dtype as mstype
from mindspore.context import ParallelMode
from mindspore.nn.wrap.grad_reducer import DistributedGradReducer
from mindspore.communication.management import get_group_size
from src.loss import NLLLoss
from mindspore.parallel._utils import _get_device_num, _get_parallel_mode, _get_gradients_mean

class GRUWithLossCell(nn.Cell):
    """
    GRU network connect with loss function.

    Args:
        network: The training network.

    Returns:
        the output of loss function.
    """

    def __init__(self, network):
        super(GRUWithLossCell, self).__init__()
        self.network = network
        self.loss = NLLLoss()
        self.logits_shape = (-1, 54359)
        self.reshape = P.Reshape()
        self.cast = P.Cast()
        self.mean = P.ReduceMean()
        self.text_len = 64
        self.split = P.Split(axis=0, output_num=64 - 1)
        self.squeeze = P.Squeeze()
        self.add = P.AddN()
        self.transpose = P.Transpose()
        self.shape = P.Shape()

    def construct(self, encoder_inputs, decoder_inputs, teacher_force):
        '''
        GRU loss cell

        Args:
            encoder_inputs(Tensor): encoder inputs
            decoder_inputs(Tensor): decoder inputs
            teacher_force(Tensor): teacher force flag

        Returns:
            loss(scalar): loss output
        '''
        logits = self.network(encoder_inputs, decoder_inputs, teacher_force)
        logits = self.cast(logits, mstype.float32)
        loss_total = ()
        decoder_targets = decoder_inputs
        decoder_output = logits
        for i in range(1, self.text_len):
            loss = self.loss(self.squeeze(decoder_output[i - 1:i:1, ::, ::]), decoder_targets[:, i])
            loss_total += (loss,)
        loss = self.add(loss_total) / self.text_len
        return loss


grad_scale = C.MultitypeFuncGraph("grad_scale")
reciprocal = P.Reciprocal()
GRADIENT_CLIP_TYPE = 1
GRADIENT_CLIP_VALUE = 1.0


class ClipGradients(nn.Cell):
    """
    Clip gradients.

    Args:
        grads (list): List of gradient tuples.
        clip_type (Tensor): The way to clip, 'value' or 'norm'.
        clip_value (Tensor): Specifies how much to clip.

    Returns:
        List, a list of clipped_grad tuples.
    """

    def __init__(self):
        super(ClipGradients, self).__init__()
        self.clip_by_norm = nn.ClipByNorm()
        self.cast = P.Cast()
        self.dtype = P.DType()

    def construct(self,
                  grads,
                  clip_type,
                  clip_value):
        """Defines the gradients clip."""
        if clip_type not in (0, 1):
            return grads
        new_grads = ()
        for grad in grads:
            dt = self.dtype(grad)
            if clip_type == 0:
                t = C.clip_by_value(grad, self.cast(F.tuple_to_array((-clip_value,)), dt),
                                    self.cast(F.tuple_to_array((clip_value,)), dt))
            else:
                t = self.clip_by_norm(grad, self.cast(F.tuple_to_array((clip_value,)), dt))
            t = self.cast(t, dt)
            new_grads = new_grads + (t,)
        return new_grads


@grad_scale.register("Tensor", "Tensor")
def tensor_grad_scale(scale, grad):
    return grad * F.cast(reciprocal(scale), F.dtype(grad))


_grad_overflow = C.MultitypeFuncGraph("_grad_overflow")
grad_overflow = P.FloatStatus()


@_grad_overflow.register("Tensor")
def _tensor_grad_overflow(grad):
    return grad_overflow(grad)


class GRUTrainOneStepWithLossScaleCell(nn.Cell):
    def __init__(self, network, optimizer, scale_update_cell=None):
        super(GRUTrainOneStepWithLossScaleCell, self).__init__(auto_prefix=False)
        self.network = network
        self.network.set_grad()
        self.network.add_flags(defer_inline=True)
        self.weights = ParameterTuple(network.trainable_params())
        self.optimizer = optimizer
        self.grad = C.GradOperation(get_by_list=True, sens_param=True)
        self.reducer_flag = False
        self.allreduce = P.AllReduce()

        self.parallel_mode = _get_parallel_mode()
        if self.parallel_mode in [ParallelMode.DATA_PARALLEL, ParallelMode.HYBRID_PARALLEL]:
            self.reducer_flag = True
        self.grad_reducer = None
        if self.reducer_flag:
            mean = _get_gradients_mean()
            degree = _get_device_num()
            self.grad_reducer = DistributedGradReducer(optimizer.parameters, mean, degree)

        self.is_distributed = (self.parallel_mode != ParallelMode.STAND_ALONE)
        self.cast = P.Cast()
        self.reduce_sum = P.ReduceSum(keep_dims=False)
        self.base = Tensor(1, mstype.float32)
        self.less_equal = P.LessEqual()
        self.hyper_map = C.HyperMap()
        self.loss_scale = None
        self.loss_scaling_manager = scale_update_cell
        if scale_update_cell:
            self.loss_scale = Parameter(Tensor(scale_update_cell.get_loss_scale(), dtype=mstype.float32))

    def construct(self, encoder_inputs, decoder_inputs, teacher_force, sens=None):
        weights = self.weights
        loss = self.network(encoder_inputs, decoder_inputs, teacher_force)

        if sens is None:
            scaling_sens = self.loss_scale
        else:
            scaling_sens = sens

        grads = self.grad(self.network, weights)(encoder_inputs,
                                                 decoder_inputs,
                                                 teacher_force,
                                                 self.cast(scaling_sens, mstype.float32))

        grads = self.hyper_map(F.partial(grad_scale, scaling_sens), grads)

        if self.reducer_flag:
            grads = self.grad_reducer(grads)

        # 处理溢出情况
        cond = F.cast(F.zeros_like(loss), mstype.bool_)  # 创建一个与 loss 形状相同的布尔张量
        if sens is None:
            cond = self.loss_scaling_manager(self.loss_scale, cond)

        if self.is_distributed:
            # 对于分布式场景，确保 cond 是标量
            cond = self.reduce_sum(F.cast(cond, mstype.float32))
            cond = self.cast(cond, mstype.bool_)

        # 无论是否溢出，都返回相同类型的值
        if cond:
            grads = self.hyper_map(F.partial(F.zeros_like), grads)
        success = self.optimizer(grads)

        return F.depend((loss, cond, scaling_sens), success)

