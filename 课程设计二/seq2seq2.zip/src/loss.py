import mindspore.ops.operations as P
from mindspore.nn.loss.loss import _Loss
from mindspore.ops import functional as F

class NLLLoss(_Loss):
    '''
    NLLLoss function
    '''
    def __init__(self, reduction='mean'):
        super(NLLLoss, self).__init__(reduction)
        self.one_hot = P.OneHot()
        self.reduce_sum = P.ReduceSum()
        # 新增 scalar_to_tensor 操作
        self.scalar_to_tensor = P.ScalarToTensor()

    def construct(self, logits, label):
        label_one_hot = self.one_hot(
            label,
            F.shape(logits)[-1],
            self.scalar_to_tensor(1.0),  # 使用 ScalarToTensor
            self.scalar_to_tensor(0.0)   # 使用 ScalarToTensor
        )
        loss = self.reduce_sum(-1.0 * logits * label_one_hot, (1,))
        return self.get_loss(loss)