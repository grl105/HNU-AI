import mindspore.nn as nn
import mindspore.ops.operations as P
import mindspore.common.dtype as mstype

from src.weight_init import gru_default_state


class BidirectionGRU(nn.Cell):
    '''
    BidirectionGRU model
    '''

    def __init__(self, is_training=True):
        super(BidirectionGRU, self).__init__()
        if is_training:
            self.batch_size = 8
        else:
            self.batch_size = 1
        self.embedding_size = 256
        self.hidden_size = 512
        self.weight_i, self.weight_h, self.bias_i, self.bias_h, self.init_h = gru_default_state(self.batch_size,
                                                                                                self.embedding_size,
                                                                                                self.hidden_size)
        self.weight_bw_i, self.weight_bw_h, self.bias_bw_i, self.bias_bw_h, self.init_bw_h = \
            gru_default_state(self.batch_size, self.embedding_size, self.hidden_size)
        self.reverse = P.ReverseV2(axis=[1])
        self.concat = P.Concat(axis=2)
        self.squeeze = P.Squeeze(axis=0)
        self.rnn = P.DynamicGRUV2()
        self.text_len = 64
        self.cast = P.Cast()

    def construct(self, x):
        '''
        BidirectionGRU construction

        Args:
            x(Tensor): BidirectionGRU input

        Returns:
            output(Tensor): rnn output
            hidden(Tensor): hidden state
        '''
        x = self.cast(x, mstype.float16)
        y1, _, _, _, _, _ = self.rnn(x, self.weight_i, self.weight_h, self.bias_i, self.bias_h, None, self.init_h)
        bw_x = self.reverse(x)
        y1_bw, _, _, _, _, _ = self.rnn(bw_x, self.weight_bw_i,
                                        self.weight_bw_h, self.bias_bw_i, self.bias_bw_h, None, self.init_bw_h)
        y1_bw = self.reverse(y1_bw)
        output = self.concat((y1, y1_bw))
        hidden = self.concat((y1[self.text_len - 1:self.text_len:1, ::, ::],
                              y1_bw[self.text_len - 1:self.text_len:1, ::, ::]))
        hidden = self.squeeze(hidden)
        return output, hidden


class GRU(nn.Cell):
    '''
    GRU model
    '''

    def __init__(self, is_training=True):
        super(GRU, self).__init__()
        if is_training:
            self.batch_size = 8
        else:
            self.batch_size = 1
        self.embedding_size = 256
        self.hidden_size = 512
        self.weight_i, self.weight_h, self.bias_i, self.bias_h, self.init_h = \
            gru_default_state(self.batch_size, self.embedding_size + self.hidden_size * 2, self.hidden_size)
        self.rnn = P.DynamicGRUV2()
        self.cast = P.Cast()

    def construct(self, x):
        '''
        GRU construction

        Args:
            x(Tensor): GRU input

        Returns:
            output(Tensor): rnn output
            hidden(Tensor): hidden state
        '''
        x = self.cast(x, mstype.float16)
        y1, h1, _, _, _, _ = self.rnn(x, self.weight_i, self.weight_h, self.bias_i, self.bias_h, None, self.init_h)
        return y1, h1
