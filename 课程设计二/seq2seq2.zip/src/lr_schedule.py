import math


def rsqrt_decay(warmup_steps, current_step):
    return float(max([current_step, warmup_steps])) ** -0.5


def linear_warmup_learning_rate(current_step, warmup_steps, base_lr, init_lr):
    lr_inc = (float(base_lr) - float(init_lr)) / float(warmup_steps)
    learning_rate = float(init_lr) + lr_inc * current_step
    return learning_rate


def a_cosine_learning_rate(current_step, base_lr, warmup_steps, total_steps):
    decay_steps = total_steps - warmup_steps
    linear_decay = (total_steps - current_step) / decay_steps
    cosine_decay = 0.5 * (1 + math.cos(math.pi * 2 * 0.47 * current_step / decay_steps))
    decayed = linear_decay * cosine_decay + 0.00001
    learning_rate = decayed * base_lr
    return learning_rate


def dynamic_lr(base_step):
    """dynamic learning rate generator"""
    base_lr = 0.001
    total_steps = int(base_step * 30)
    warmup_steps = int(300)
    lr = []
    for i in range(total_steps):
        if i < warmup_steps:
            lr.append(linear_warmup_learning_rate(i, warmup_steps, base_lr, base_lr * 300))
        else:
            lr.append(a_cosine_learning_rate(i, base_lr, warmup_steps, total_steps))
    return lr
