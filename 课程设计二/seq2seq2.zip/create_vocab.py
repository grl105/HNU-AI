import os
import argparse
from collections import Counter
import nltk
import jieba
from nltk.tokenize import word_tokenize

#nltk.download('punkt')

def create_tokenized_sentences(input_files, language):
    sentences = []
    total_lines = open(input_files, "r", encoding="utf-8").read().splitlines()
    for line in total_lines:
        line = line.strip("\r\n")
        line = line.lower()
        if language == "chinese":
            tokenize_sentence = list(jieba.cut(line))
        else:
            tokenize_sentence = word_tokenize(line)
        str_sentence = " ".join(tokenize_sentence)
        sentences.append(str_sentence)

    tokenize_file = input_files + ".tok"
    f = open(tokenize_file, "w", encoding="utf-8")
    for line in sentences:
        f.write(line)
        f.write("\n")
    f.close()


def get_dataset_vocab(text_file, vocab_file):
    counter = Counter()
    text_lines = open(text_file, "r", encoding="utf-8").read().splitlines()
    for line in text_lines:
        for word in line.strip("\r\n").split(" "):
            if word:
                counter[word] += 1

    vocab = open(vocab_file, "w", encoding="utf-8")
    basic_label = ["<unk>", "<pad>", "<sos>", "<eos>"]
    for label in basic_label:
        vocab.write(label + "\n")
    for key, f in sorted(counter.items(), key=lambda x: x[1], reverse=True):
        if f < 2:
            continue
        vocab.write(key + "\n")
    vocab.close()


def merge_text(root_dir, file_list, output_file):
    output_file = os.path.join(root_dir, output_file)
    f_output = open(output_file, "w", encoding="utf-8")
    for file_name in file_list:
        text_path = os.path.join(root_dir, file_name) + ".tok"
        f = open(text_path, encoding="utf-8")
        f_output.write(f.read() + "\n")
    f_output.close()


if __name__ == "__main__":
    dataset_path = "./nltk_predata"
    os.makedirs(dataset_path, exist_ok=True)

    dst_file_list = ["train.zh", "test.zh", "valid.zh"]
    src_file_list = ["train.en", "test.en", "valid.en"]

    # Create tokenized files
    for file in src_file_list:
        file_path = os.path.join(dataset_path, file)
        create_tokenized_sentences(file_path, "english")

    for file in dst_file_list:
        file_path = os.path.join(dataset_path, file)
        create_tokenized_sentences(file_path, "chinese")

    # Merge files
    src_all_file = "all.en.tok"
    dst_all_file = "all.zh.tok"
    merge_text(dataset_path, src_file_list, src_all_file)
    merge_text(dataset_path, dst_file_list, dst_all_file)

    # Create vocabularies
    src_vocab = os.path.join(dataset_path, "vocab.en")
    dst_vocab = os.path.join(dataset_path, "vocab.zh")
    get_dataset_vocab(os.path.join(dataset_path, src_all_file), src_vocab)
    get_dataset_vocab(os.path.join(dataset_path, dst_all_file), dst_vocab)