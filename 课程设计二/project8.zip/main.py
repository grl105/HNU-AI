import mindspore as ms
import mindspore.nn as nn
import mindspore.ops as ops
import mindspore.dataset as ds
from mindspore import Tensor, context
import numpy as np
from collections import Counter
import os
import json
import random
from tqdm import tqdm
from typing import List, Dict
import math
import time

# 设置运行环境
context.set_context(mode=context.GRAPH_MODE, device_target="CPU")
# 在代码开头可以尝试增加调用深度限制
context.set_context(max_call_depth=3000)  # 增加调用深度限制

class Config:
    def __init__(self):
        # 基本配置
        self.batch_size = 16
        self.max_length = 30
        self.embed_size = 128
        self.hidden_size = 256
        self.num_layers = 1
        self.dropout = 0.3
        self.learning_rate = 0.005
        self.num_epochs = 5

        # 训练配置
        self.clip = 1.0
        self.teacher_forcing_ratio = 0.5

        # 特殊标记
        self.PAD_token = 0
        self.SOS_token = 1
        self.EOS_token = 2

        # 数据路径
        self.train_zh = "train.zh"
        self.train_en = "train.en"
        self.valid_zh = "valid.zh"
        self.valid_en = "valid.en"
        self.test_zh = "test.zh"
        self.test_en = "test.en"

        # 数据采样限制
        self.max_samples = 7000  # 设置为None使用全部数据
        self.max_output_length = 50

class Encoder(nn.Cell):
    def __init__(self, vocab_size, embed_size, hidden_size, num_layers, dropout):
        super().__init__()
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        # 修改这里，移除 dtype 参数
        self.embedding = nn.Embedding(vocab_size, embed_size)

        self.rnn = nn.LSTM(
            input_size=embed_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            has_bias=True,
            batch_first=False,
            bidirectional=False
        )

    def construct(self, x):
        batch_size = x.shape[0]

        # 确保初始隐藏状态是 float32
        h = ops.ones((self.num_layers, batch_size, self.hidden_size), ms.float32)
        c = ops.ones((self.num_layers, batch_size, self.hidden_size), ms.float32)

        # 确保输入是 float32
        x = ops.cast(x, ms.int32)  # 先转为 int32 再进入 embedding
        embedded = self.embedding(x)  # embedding 输出应该已经是 float32
        embedded = ops.cast(embedded, ms.float32)  # 确保是 float32
        embedded = ops.transpose(embedded, (1, 0, 2))

        # 确保所有输入都是 float32
        output, (hidden, cell) = self.rnn(embedded, (h, c))
        return output, hidden, cell

class Decoder(nn.Cell):
    def __init__(self, output_size, embed_size, hidden_size, num_layers, dropout):
        super().__init__()
        self.output_size = output_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        # 修改这里，移除 dtype 参数
        self.embedding = nn.Embedding(output_size, embed_size)

        self.rnn = nn.LSTM(
            input_size=embed_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            has_bias=True,
            batch_first=False,
            bidirectional=False
        )

        self.fc = nn.Dense(hidden_size, output_size)

    def construct(self, x, hidden, cell):
        # 确保输入都是正确的类型
        x = ops.cast(x, ms.int32)
        hidden = ops.cast(hidden, ms.float32)
        cell = ops.cast(cell, ms.float32)

        # 确保 embedding 输出是 float32
        embedded = self.embedding(x)
        embedded = ops.cast(embedded, ms.float32)
        embedded = ops.transpose(embedded, (1, 0, 2))

        # 确保所有输入都是 float32
        output, (hidden, cell) = self.rnn(embedded, (hidden, cell))
        output = ops.transpose(output, (1, 0, 2))
        prediction = self.fc(output.squeeze(1))

        return prediction, hidden, cell


class Seq2Seq(nn.Cell):
    def __init__(self, encoder, decoder):
        super(Seq2Seq, self).__init__()  # 这一行是关键，确保正确初始化父类
        self.encoder = encoder
        self.decoder = decoder

    def construct(self, src, trg=None, teacher_forcing_ratio=0.5):
        batch_size = src.shape[0]
        max_len = trg.shape[1] if trg is not None else 30
        vocab_size = self.decoder.output_size

        outputs = []
        _, hidden, cell = self.encoder(src)
        decoder_input = ops.ones((batch_size, 1), ms.int32)

        for t in range(max_len):
            decoder_output, hidden, cell = self.decoder(decoder_input, hidden, cell)
            outputs.append(decoder_output)

            if trg is not None and t < max_len - 1 and random.random() < teacher_forcing_ratio:
                decoder_input = trg[:, t:t+1]
            else:
                decoder_input = ops.cast(decoder_output.argmax(1, keepdims=True), ms.int32)

        outputs = ops.stack(outputs, axis=1)
        return outputs


class TranslationDataset:
    def __init__(self, config):
        self.config = config
        self.src_vocab = Vocabulary()
        self.tgt_vocab = Vocabulary()

        print("Building vocabulary...")
        self._build_vocab(config.train_zh, config.train_en)

        print("Loading datasets...")
        self.train_data = self._load_data(config.train_zh, config.train_en, config.max_samples)
        self.valid_data = self._load_data(config.valid_zh, config.valid_en, config.max_samples // 10)
        self.test_data = self._load_data(config.test_zh, config.test_en, config.max_samples // 10)

    def _build_vocab(self, src_path, tgt_path):
        """构建词表"""
        try:
            with open(src_path, 'r', encoding='utf-8', errors='ignore') as f:
                print(f"Processing source language file: {src_path}")
                lines = f.readlines()
                if self.config.max_samples:
                    lines = lines[:self.config.max_samples]
                for line in tqdm(lines):
                    self.src_vocab.add_sentence(line.strip())

            with open(tgt_path, 'r', encoding='utf-8', errors='ignore') as f:
                print(f"Processing target language file: {tgt_path}")
                lines = f.readlines()
                if self.config.max_samples:
                    lines = lines[:self.config.max_samples]
                for line in tqdm(lines):
                    self.tgt_vocab.add_sentence(line.strip())

        except Exception as e:
            print(f"Error processing files: {str(e)}")
            raise

    def _load_data(self, src_path, tgt_path, max_samples=None):
        """加载数据"""
        data = []
        try:
            with open(src_path, 'r', encoding='utf-8', errors='ignore') as src_f, \
                    open(tgt_path, 'r', encoding='utf-8', errors='ignore') as tgt_f:

                src_lines = src_f.readlines()
                tgt_lines = tgt_f.readlines()

                if max_samples:
                    src_lines = src_lines[:max_samples]
                    tgt_lines = tgt_lines[:max_samples]

                for src_line, tgt_line in tqdm(zip(src_lines, tgt_lines)):
                    src_tokens = src_line.strip().split()
                    tgt_tokens = tgt_line.strip().split()

                    if len(src_tokens) <= self.config.max_length and \
                            len(tgt_tokens) <= self.config.max_length:
                        src_indices = [self.src_vocab.word2idx.get(token, self.src_vocab.word2idx['<unk>'])
                                       for token in src_tokens]
                        tgt_indices = [self.tgt_vocab.word2idx.get(token, self.tgt_vocab.word2idx['<unk>'])
                                       for token in tgt_tokens]

                        src_indices.append(self.config.EOS_token)
                        tgt_indices.append(self.config.EOS_token)

                        src_indices = self._pad_sequence(src_indices)
                        tgt_indices = self._pad_sequence(tgt_indices)

                        data.append((src_indices, tgt_indices))

        except Exception as e:
            print(f"Error loading data: {str(e)}")
            raise

        return data

    def _pad_sequence(self, sequence):
        if len(sequence) < self.config.max_length:
            sequence = sequence + [self.config.PAD_token] * (self.config.max_length - len(sequence))
        return sequence[:self.config.max_length]

    def get_batch(self, data, batch_size):
        data = list(data)
        random.shuffle(data)

        for i in range(0, len(data), batch_size):
            batch = data[i:i + batch_size]
            if len(batch) < batch_size:
                continue

            src_batch, tgt_batch = zip(*batch)

            try:
                src_array = np.array(src_batch, dtype=np.int32)
                tgt_array = np.array(tgt_batch, dtype=np.int32)

                src_tensor = Tensor(src_array, dtype=ms.int32)
                tgt_tensor = Tensor(tgt_array, dtype=ms.int32)

                yield src_tensor, tgt_tensor

            except Exception as e:
                print(f"Error creating batch: {str(e)}")
                continue


def train_model(model, dataset, config):
    model.set_train()
    criterion = nn.CrossEntropyLoss(ignore_index=config.PAD_token)
    optimizer = nn.Adam(model.trainable_params(), learning_rate=config.learning_rate)

    def forward_fn(data, target):
        output = model(data, target)
        # 添加形状检查和调整
        if len(output.shape) != 3:
            output = output.view(output.shape[0], -1, output.shape[-1])
        if len(target.shape) != 2:
            target = target.view(target.shape[0], -1)

        print(f"Output shape: {output.shape}")
        print(f"Target shape: {target.shape}")

        output = output.view(-1, output.shape[-1])  # (batch_size * seq_len, vocab_size)
        target = target.view(-1)  # (batch_size * seq_len)
        loss = criterion(output, target)
        return loss

    grad_fn = ops.value_and_grad(forward_fn, None, optimizer.parameters, has_aux=False)


    def train_step(data, target):
        loss, grads = grad_fn(data, target)
        optimizer(grads)
        return loss

    best_valid_loss = float('inf')
    total_batches = len(dataset.train_data) // config.batch_size

    for epoch in range(config.num_epochs):
        epoch_loss = 0
        batch_count = 0
        start_time = time.time()

        print(f"\nEpoch {epoch + 1}/{config.num_epochs}")

        for src_batch, tgt_batch in dataset.get_batch(dataset.train_data, config.batch_size):
            loss = train_step(src_batch, tgt_batch)
            epoch_loss += loss.asnumpy()
            batch_count += 1

            if batch_count % 5 == 0:
                current_loss = epoch_loss / batch_count
                progress = (batch_count / total_batches) * 100
                elapsed_time = time.time() - start_time
                print(f"Progress: {progress:.1f}% ({batch_count}/{total_batches} batches)")
                print(f"Current Loss: {current_loss:.4f}")
                print(f"Time elapsed: {elapsed_time:.1f}s")
                print("-" * 50)

        avg_loss = epoch_loss / batch_count
        print(f"Epoch {epoch + 1} Average Loss: {avg_loss:.4f}")

        # 验证
        valid_loss = validate_model(model, dataset, config, criterion)
        print(f"Validation Loss: {valid_loss:.4f}")

        if valid_loss < best_valid_loss:
            best_valid_loss = valid_loss
            ms.save_checkpoint(model, 'best_model.ckpt')
            print("Saved new best model!")

def validate_model(model, dataset, config, criterion):
    """验证模型"""
    model.set_train(False)
    total_loss = 0
    batch_count = 0

    for src_batch, tgt_batch in dataset.get_batch(dataset.valid_data, config.batch_size):
        output = model(src_batch, tgt_batch, 0.0)
        output = output.view(-1, output.shape[-1])
        tgt_batch = tgt_batch.view(-1)
        loss = criterion(output, tgt_batch)
        total_loss += loss.asnumpy()
        batch_count += 1

    model.set_train(True)
    return total_loss / batch_count


class Vocabulary:
    def __init__(self):
        self.word2idx = {"<pad>": 0, "<sos>": 1, "<eos>": 2, "<unk>": 3}
        self.idx2word = {0: "<pad>", 1: "<sos>", 2: "<eos>", 3: "<unk>"}
        self.word_count = {}
        self.n_words = 4  # 初始有4个特殊标记

    def add_sentence(self, sentence):
        for word in sentence.split():
            self.add_word(word)

    def add_word(self, word):
        if word not in self.word2idx:
            self.word2idx[word] = self.n_words
            self.word_count[word] = 1
            self.idx2word[self.n_words] = word
            self.n_words += 1
        else:
            self.word_count[word] += 1


def evaluate_model(model, dataset, config):
    model.set_train(False)

    # 计算BLEU分数
    bleu_scores = {1: 0.0, 2: 0.0, 3: 0.0}
    references = []
    candidates = []

    for src_batch, tgt_batch in dataset.get_batch(dataset.test_data, config.batch_size):
        output = model(src_batch, tgt_batch, 0.0)
        output_indices = output.argmax(2).asnumpy()

        # 将索引转换回单词
        for i in range(len(output_indices)):
            candidate = []
            reference = []

            for idx in output_indices[i]:
                if idx == config.EOS_token:
                    break
                candidate.append(dataset.tgt_vocab.idx2word[idx])

            for idx in tgt_batch[i].asnumpy():
                if idx == config.EOS_token:
                    break
                reference.append(dataset.tgt_vocab.idx2word[idx])

            candidates.append(candidate)
            references.append(reference)

    # 计算不同阶的BLEU分数
    for n in [1, 2, 3]:
        bleu_scores[n] = calculate_bleu(references, candidates, n)

    # 计算困惑度
    perplexity = calculate_perplexity(model, dataset.test_data, config)

    return bleu_scores, perplexity


def translate(model, sentence, src_vocab, tgt_vocab, config):
    model.set_train(False)

    # 处理输入句子
    tokens = sentence.strip().split()
    input_indices = []

    # 转换输入词为索引
    for token in tokens:
        if token in src_vocab.word2idx:
            input_indices.append(src_vocab.word2idx[token])
        else:
            input_indices.append(src_vocab.word2idx['<unk>'])

    # 添加EOS
    input_indices.append(config.EOS_token)

    # 补齐序列
    while len(input_indices) < config.max_length:
        input_indices.append(config.PAD_token)

    # 转换为tensor
    input_tensor = Tensor([input_indices], ms.int32)

    try:
        # 生成翻译
        with ms.stop_gradient():
            output = model(input_tensor, None, 0.0)

        # 获取预测的词索引
        output_indices = output.argmax(2).asnumpy()[0]

        # 转换回单词
        words = []
        for idx in output_indices:
            if idx == config.EOS_token:
                break
            if idx == config.PAD_token:
                continue
            words.append(tgt_vocab.idx2word[idx])

        return ' '.join(words) if words else '<生成失败>'

    except Exception as e:
        print(f"翻译过程出错: {str(e)}")
        return '<翻译错误>'


def load_trained_model(config, src_vocab_size, tgt_vocab_size):
    # 创建模型实例
    encoder = Encoder(
        vocab_size=src_vocab_size,
        embed_size=config.embed_size,
        hidden_size=config.hidden_size,
        num_layers=config.num_layers,
        dropout=config.dropout
    )

    decoder = Decoder(
        output_size=tgt_vocab_size,
        embed_size=config.embed_size,
        hidden_size=config.hidden_size,
        num_layers=config.num_layers,
        dropout=config.dropout
    )

    # 修改这里，只传入 encoder 和 decoder
    model = Seq2Seq(encoder, decoder)  # 移除 config

    # 加载训练好的权重
    param_dict = ms.load_checkpoint('best_model.ckpt')
    ms.load_param_into_net(model, param_dict)

    return model


def interactive_translation():
    """
    交互式翻译接口
    """
    # 初始化配置
    config = Config()

    # 加载数据集以获取词表
    dataset = TranslationDataset(config)

    # 加载训练好的模型
    model = load_trained_model(config, dataset.src_vocab.n_words, dataset.tgt_vocab.n_words)

    print("翻译系统已启动！")
    print("输入 'q' 或 'quit' 退出系统")
    print("输入 'switch' 切换翻译方向")

    # 默认中译英
    zh_to_en = 0

    while True:
        if zh_to_en:
            print("\n当前模式：中译英")
        else:
            print("\n当前模式：英译中")

        sentence = input("\n请输入要翻译的句子: ").strip()

        if sentence.lower() in ['q', 'quit']:
            print("翻译系统已关闭！")
            break

        if sentence.lower() == 'switch':
            zh_to_en = not zh_to_en
            continue

        if sentence:
            try:
                if zh_to_en:
                    translated = translate(model, sentence,
                                           dataset.src_vocab, dataset.tgt_vocab, config)
                else:
                    translated = translate(model, sentence,
                                           dataset.tgt_vocab, dataset.src_vocab, config)
                print(f"翻译结果: {translated}")
            except Exception as e:
                print(f"翻译出错: {str(e)}")
                print("请检查输入格式是否正确")


def calculate_ngram_counts(tokens: List[str], n: int) -> Counter:
    """计算n-gram出现次数"""
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def calculate_bleu(references: List[List[str]], candidates: List[List[str]], n: int) -> float:
    """
    计算n阶BLEU分数

    Args:
        references: 参考翻译列表
        candidates: 候选翻译列表
        n: n-gram的n值

    Returns:
        float: BLEU分数
    """
    clipped_counts = 0
    total_counts = 0

    for ref, cand in zip(references, candidates):
        ref_counts = calculate_ngram_counts(ref, n)
        cand_counts = calculate_ngram_counts(cand, n)

        for ngram, count in cand_counts.items():
            total_counts += count
            clipped_counts += min(count, ref_counts[ngram])

    if total_counts == 0:
        return 0.0

    return clipped_counts / total_counts


def calculate_perplexity(model, test_data: List, config: Config) -> float:
    """
    计算困惑度

    Args:
        model: 训练好的模型
        test_data: 测试数据
        config: 配置对象

    Returns:
        float: 困惑度值
    """
    model.set_train(False)
    total_loss = 0
    total_words = 0
    criterion = nn.CrossEntropyLoss(ignore_index=config.PAD_token, reduction='sum')


    for src_seq, tgt_seq in test_data:
        # 转换为tensor
        src_tensor = Tensor([src_seq], ms.int32)
        tgt_tensor = Tensor([tgt_seq], ms.int32)

        # 前向传播
        output = model(src_tensor, tgt_tensor, 0.0)
        output = output.view(-1, output.shape[-1])
        tgt_tensor = tgt_tensor.view(-1)

        # 计算损失
        loss = criterion(output, tgt_tensor)
        total_loss += loss.asnumpy()

        # 统计非填充词的数量
        non_pad = tgt_tensor.asnumpy() != config.PAD_token
        total_words += np.sum(non_pad)

    # 计算困惑度
    perplexity = math.exp(total_loss / total_words if total_words > 0 else float('inf'))
    return perplexity

def train_and_evaluate():
    """训练和评估模型"""
    try:
        # 初始化配置
        config = Config()

        # 加载数据
        dataset = TranslationDataset(config)

        # 创建模型
        encoder = Encoder(
            vocab_size=dataset.src_vocab.n_words,
            embed_size=config.embed_size,
            hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            dropout=config.dropout
        )

        decoder = Decoder(
            output_size=dataset.tgt_vocab.n_words,
            embed_size=config.embed_size,
            hidden_size=config.hidden_size,
            num_layers=config.num_layers,
            dropout=config.dropout
        )

        # 只传入 encoder 和 decoder，移除 config
        model = Seq2Seq(encoder, decoder)

        # 训练模型
        print("Starting training...")
        train_model(model, dataset, config)


        # 评估模型
        print("Evaluating model...")
        bleu_scores, perplexity = evaluate_model(model, dataset, config)

        print("\nEvaluation Results:")
        print(f"BLEU-1: {bleu_scores[1]:.4f}")
        print(f"BLEU-2: {bleu_scores[2]:.4f}")
        print(f"BLEU-3: {bleu_scores[3]:.4f}")
        print(f"Perplexity: {perplexity:.4f}")

        return model, dataset, config

    except Exception as e:
        print(f"Error in training and evaluation: {str(e)}")
        raise


def main():
    """主函数"""
    try:
        while True:
            print("\n请选择操作：")
            print("1. 训练新模型")
            print("2. 使用已有模型进行翻译")
            print("3. 退出")

            choice = input("请输入选项编号: ").strip()

            if choice == '1':
                train_and_evaluate()
            elif choice == '2':
                interactive_translation()
            elif choice == '3':
                print("程序已退出")
                break
            else:
                print("无效的选项，请重新选择")

    except KeyboardInterrupt:
        print("\n程序已被用户中断")
    except Exception as e:
        print(f"发生错误: {str(e)}")


if __name__ == "__main__":
    main()